import React from "react";
import './Roubin.css';
const Roubin = () => {
    return (
        <div>
            <h1 className="handlename">What can I do as a them ?</h1>
            <div class="management">
                <div class="robin">
                    <img src="robin.jpeg" />
                    <h1> Round Robin Scheduling </h1>
                    <p>automatically assign meeting based on what makes the most sense for your term's goals- whether by availabilty priorty or equal"</p>
                    <button>watch video</button>
                </div>
                <div class="robin">
                    <img src="powrful.jpeg" />
                    <h1> Access Powerful Management Tools</h1>
                    <p>Get new and existing users up to speed and engaged with event type templates to make sure everyone's set up for efficient scheduling, all managed through one centralized billing solution.</p>
                    <button>watch video</button>
                </div>
            </div>
        </div>

    )
}
export default Roubin;