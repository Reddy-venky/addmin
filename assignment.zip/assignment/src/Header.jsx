import React from "react";
import logo from './logo.svg';
import './Header.css';
const Header = () => {
    return (

        <div>
            <header class="app">
                <img src="admin.jpg" />
                <div class="links">
                    <a href="#">Home</a>
                    <a href="#">Availabilty</a>
                    <a href="#">integrations</a>
                    <a href="#">help<select>help</select></a>
                    <a href="#" class="alfa">J</a>
                    <a href="#">account<select></select></a>
                </div>
                </header>
            <div className="contanier" >
                <p><span className="admin">Admin Management</span> 1/1seats occupied</p>
                <div>
                <button>+New User</button>
                </div>
            </div>
            <div class="event">
                <a href="">All People</a>
                <a href="">Groups</a> 
                <a href="">Manged Event</a>

                <button>BETA</button>
                             
            </div>
          
        </div>



    )
}
export default Header;