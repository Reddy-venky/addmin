import React from "react";
import './Maincontant.css'


const Maincontant=()=>{
    return(
        
              <div class="mainbody">
                <h2> Start building your organization</h2>
                <p>invite to user unclock unique team scheduling feactures starting as low  as $12 per user/mo </p>
                    <br />
                <button>invite users</button>
        
            </div>
            
        
    )
}
export default Maincontant;
